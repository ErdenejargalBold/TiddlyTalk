from flask import Flask, jsonify, request
from flask_cors import CORS 
#Code for analysing word accuracy
from faster_whisper import WhisperModel
import tensorflow as tf
import math
import google.generativeai as genai

apiKey = "AIzaSyAsSdRNg-BgYCbSwR1TMiG7XvPPkCIdGi0" # If you use API key, please set your API key.


genai.configure(api_key=apiKey)
model = genai.GenerativeModel("gemini-pro")

chat = model.start_chat()


def get_chat_response(chat: genai.ChatSession, prompt: str) -> str:
    response = chat.send_message(prompt)
    return response.text


# Set environment variable to use CPU only (if not already set)
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

app = Flask(__name__)
CORS(app)

# Example endpoint to handle POST request from React
@app.route('/api/data', methods=['POST'])
def receive_data():
    data = request.json  # Assuming the request sends JSON data
    # Process the data as needed
    print(data)

    model_size = "base"
    model = WhisperModel(model_size)

    print("...model size...")

    #Change the audio file here
    audio = "C:\\Users\\erden\\Downloads\\recorded_audio.wav"
    
    print("... got audio file ...")
    
    segments, info = model.transcribe(audio, beam_size=1, word_timestamps=True)
    
    print("...segmented ... ")
    
    for segment in segments:
        for word in segment.words:
            print(word, word.probability)
            if word.probability < 0.2:
                response = "Did you mean" + word.word
            elif word.probability < 0.3 and word.probability > 0.2:
                response = "Almost! Try saying " + word.word
            elif word.probability > 0.3:
                 response = "Congratulations! You said " + word.word + " correctly!"
                 prompt = "pretend I'm a 2 year old baby. I just said the word " + word.word + " correctly. Try to get me to say 1 other word slightly but not quite related to it. Just a 1 sentence in your response please, make it conversational and don't ask me to say something i've already said. E.g. if i've already said hello, dont ask me to say hello again."
                 response += get_chat_response(chat, prompt)
    try:
        os.remove(audio)
    except:
        pass
    return jsonify({'word': word.word, 'advise': response, 'wp': math.floor(word.probability*100)})

if __name__ == '__main__':
    app.run(debug=True)
