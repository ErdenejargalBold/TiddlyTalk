from flask import Flask, jsonify, request
from flask_cors import CORS 
#Code for analysing word accuracy
from faster_whisper import WhisperModel
import tensorflow as tf
import math

# Set environment variable to use CPU only (if not already set)
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

app = Flask(__name__)
CORS(app)

# Example endpoint to handle POST request from React
@app.route('/api/data', methods=['POST'])
def receive_data():
    data = request.json  # Assuming the request sends JSON data
    # Process the data as needed
    print(data)

    model_size = "base"
    model = WhisperModel(model_size)

    print("...model size...")

    #Change the audio file here
    audio = "C:\\Users\\erden\\Downloads\\recorded_audio.wav"
    
    print("... got audio file ...")
    
    segments, info = model.transcribe(audio, beam_size=1, word_timestamps=True)
    
    print("...segmented ... ")
    
    for segment in segments:
        for word in segment.words:
            print(word, word.probability)
            if word.probability < 0.7:
                print("did you mean" + word.word + "?")
    
    os.remove(audio)
    return jsonify({'word': word.word, 'wp': math.floor(word.probability*100)})
    

if __name__ == '__main__':
    app.run(debug=True)
