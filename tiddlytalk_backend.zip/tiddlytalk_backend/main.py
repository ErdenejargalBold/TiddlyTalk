#Code for analysing word accuracy
from faster_whisper import WhisperModel

model_size = "base"
model = WhisperModel(model_size)

#Change the audio file here
audio = "C:\\Users\\erden\\Downloads\\recorded_audio.wav"
segments, info = model.transcribe(audio, beam_size=1, word_timestamps=True)
for segment in segments:
    for word in segment.words:
      print(word, word.probability)

"""
import google.generativeai as genai

#AIzaSyAsSdRNg-BgYCbSwR1TMiG7XvPPkCIdGi0

genai.configure(api_key="AIzaSyAsSdRNg-BgYCbSwR1TMiG7XvPPkCIdGi0")
model = genai.GenerativeModel('gemini-1.5-flash')

count = 1
response = model.generate_content(
    "Pretend I'm a baby, around 2 years old. I'm trying to say black. I've just got the word correct. Write words only about how you would respond if you were an adult. After that, try to engage me in 2 year old level converstation about this word. Make me say another word related to black. E.g. can you say ...")
print(response.text)
while True:
    user = input("input something:")
    response = model.generate_content(user)
    print(response.text)
    

while True:
    if count == 1:
    else:
        response = model.generate_content(input())
    print(response.text)
    count += 1
"""




import pyttsx3
"""
# init function to get an engine instance for the speech synthesis
engine = pyttsx3.init()

string = 'Hello sir, how may I help you, sir.'
# say method on the engine that passing input text to be spoken
voices = engine.getProperty('voices')
print(voices)
engine.setProperty('voices', "!v/f1")
engine.say(string)
engine.save_to_file(string, 'speech.mp3')

# run and wait method, it processes the voice commands.
engine.runAndWait()
"""

import google.generativeai as genai

#AIzaSyAsSdRNg-BgYCbSwR1TMiG7XvPPkCIdGi0

import google.generativeai as genai
import random

apiKey = "AIzaSyAsSdRNg-BgYCbSwR1TMiG7XvPPkCIdGi0" # If you use API key, please set your API key.


genai.configure(api_key=apiKey)
model = genai.GenerativeModel("gemini-pro")

chat = model.start_chat()


def get_chat_response(chat: genai.ChatSession, prompt: str) -> str:
    response = chat.send_message(prompt)
    return response.text
engine = pyttsx3.init()
count = 1
word = "happy"
while True:
    try:
        if count == 1:
            prompt = "pretend I'm a 2 year old baby. I just said the word happy correctly. Try to get me to say 1 other word slightly but not quite related to it. Just a few sentences in your response please."

        else:
            prompt = input("say something:") + "pretend I'm a 2 year old baby. I just said the word correctly. Engage me in a conversation and try to get me to say 1 other word not quite related to it. Just a few sentences in your response please. Give encouragement and define it in a kid friendly way. Don't get me to say any word i've already said in this conversation. But keep it kid friendly."
    except:
        prompt = "pretend I'm a 2 year old baby. I just said a word correctly. Try to get me to say 1 other kid friendly word. Just a few sentences in your response please. "

    response = get_chat_response(chat, prompt)
    print(response)
    engine.setProperty('voice', 'com.apple.speech.synthesis.voice.samantha')
    engine.say(response)

    engine.runAndWait()
    count += 1
